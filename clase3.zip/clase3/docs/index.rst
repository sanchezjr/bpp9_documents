.. Clase 3 BPP documentation master file, created by
   sphinx-quickstart on Mon Feb 27 19:29:38 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Clase 3 BPP's documentation!
=======================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   modules

.. note:: This is a **note** box.   

.. warning:: This is a **warning** box.

.. image:: sphinx.png
    :align: center
    :width: 300px
    :alt: alternate text

.. table::
	:align: center
	:widths: auto

	+--------------------------------------+---------------------------------+
	| .. image:: sphinx.png                |                                 |
	|     :align: center                   |                                 |
	|     :width: 300px                    |                                 |
	|     :alt: alternate text             | A description can go here       |
	+--------------------------------------+---------------------------------+

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
