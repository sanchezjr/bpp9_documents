code2 module
============

.. automodule:: code2
   :members:
   :undoc-members:
   :show-inheritance:
